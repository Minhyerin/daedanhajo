const csMenu = document.querySelector(".header_menu.cs");
const csMenuList = document.querySelector(".cs_menu_list");
csMenu.addEventListener("mouseover", () => {
  csMenuList.style.display = "block";
})